package com.example.educationalapp

enum class QuizAnswerState { UNANSWERED, CORRECT, INCORRECT }
