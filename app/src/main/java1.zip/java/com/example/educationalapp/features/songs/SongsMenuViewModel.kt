package com.example.educationalapp.features.songs

import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class SongsMenuViewModel @Inject constructor() : ViewModel() {
    // TODO: Implement ViewModel logic
}
