package com.example.educationalapp.features.wowgames

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController

@Composable
fun WowGamesApp(navController: NavHostController) {
    MenuScreen(navController = navController)
}
