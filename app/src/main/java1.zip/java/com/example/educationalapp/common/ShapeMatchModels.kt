package com.example.educationalapp

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector

data class ShapeQuizQuestion(val shape: NamedShape, val options: List<NamedShape>)
