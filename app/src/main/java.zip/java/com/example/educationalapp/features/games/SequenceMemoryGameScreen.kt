package com.example.educationalapp.features.games

import android.content.Context
import android.media.AudioAttributes as AndroidAudioAttributes
import android.media.SoundPool
import android.util.Base64
import androidx.annotation.RawRes
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.SlowMotionVideo
import androidx.compose.material.icons.filled.TipsAndUpdates
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.example.educationalapp.R
import com.example.educationalapp.common.PremiumConfetti
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.datasource.RawResourceDataSource
import androidx.media3.exoplayer.ExoPlayer

// -------------------------------
// MODEL
// -------------------------------
enum class GameState { IDLE, SHOWING_SEQUENCE, PLAYER_TURN, GAME_OVER }
enum class GameMode { NORMAL, REVERSE, TIMED }

data class AnimalButtonData(
    val id: Int,
    val color: Color,
    val imageRes: Int,
    val name: String,
    @RawRes val soundRes: Int?
)

@Serializable
data class ReplayCode(
    val mode: GameMode,
    val seed: Long,
    val sequence: List<Int>,
    val score: Int
)

data class SequenceUiState(
    val gameState: GameState = GameState.IDLE,
    val mode: GameMode = GameMode.NORMAL,
    val score: Int = 0,
    val highScore: Int = 0,
    val starsAwardedThisRun: Int = 0,

    val sequence: List<Int> = emptyList(),
    val playerIndex: Int = 0,
    val activeAnimalId: Int? = null,

    val robotEmotion: RobotEmotion = RobotEmotion.IDLE,
    val showConfetti: Boolean = false,

    // Timed mode
    val timeTotalMs: Long = 0,
    val timeLeftMs: Long = 0,

    // Power-ups (state only; stars are held in parent)
    val shieldArmed: Boolean = false,
    val slowMotionTurnsLeft: Int = 0
)

enum class RobotEmotion { IDLE, HAPPY, SAD, HINT, WIN }

// -------------------------------
// DATASTORE (prefs)
// -------------------------------
private val Context.gamePrefs by preferencesDataStore("sequence_game_prefs")

@Singleton
class SequencePrefsRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private object Keys {
        val HIGH_NORMAL = intPreferencesKey("high_normal")
        val HIGH_REVERSE = intPreferencesKey("high_reverse")
        val HIGH_TIMED = intPreferencesKey("high_timed")
        val MODE_LAST = stringPreferencesKey("mode_last")
        val MUSIC_ON = booleanPreferencesKey("music_on")
        val SFX_ON = booleanPreferencesKey("sfx_on")
        val VOICE_ON = booleanPreferencesKey("voice_on")
    }

    val musicOn: Flow<Boolean> = context.gamePrefs.data.map { it[Keys.MUSIC_ON] ?: true }
    val sfxOn: Flow<Boolean> = context.gamePrefs.data.map { it[Keys.SFX_ON] ?: true }
    val voiceOn: Flow<Boolean> = context.gamePrefs.data.map { it[Keys.VOICE_ON] ?: true }
    val lastMode: Flow<GameMode> = context.gamePrefs.data.map {
        runCatching { GameMode.valueOf(it[Keys.MODE_LAST] ?: GameMode.NORMAL.name) }.getOrDefault(GameMode.NORMAL)
    }

    fun highScoreFlow(mode: GameMode): Flow<Int> = context.gamePrefs.data.map { prefs ->
        when (mode) {
            GameMode.NORMAL -> prefs[Keys.HIGH_NORMAL] ?: 0
            GameMode.REVERSE -> prefs[Keys.HIGH_REVERSE] ?: 0
            GameMode.TIMED -> prefs[Keys.HIGH_TIMED] ?: 0
        }
    }

    suspend fun setLastMode(mode: GameMode) {
        context.gamePrefs.edit { it[Keys.MODE_LAST] = mode.name }
    }

    suspend fun setMusicOn(v: Boolean) = context.gamePrefs.edit { it[Keys.MUSIC_ON] = v }
    suspend fun setSfxOn(v: Boolean) = context.gamePrefs.edit { it[Keys.SFX_ON] = v }
    suspend fun setVoiceOn(v: Boolean) = context.gamePrefs.edit { it[Keys.VOICE_ON] = v }

    suspend fun setHighScore(mode: GameMode, v: Int) {
        context.gamePrefs.edit {
            when (mode) {
                GameMode.NORMAL -> it[Keys.HIGH_NORMAL] = v
                GameMode.REVERSE -> it[Keys.HIGH_REVERSE] = v
                GameMode.TIMED -> it[Keys.HIGH_TIMED] = v
            }
        }
    }
}

// -------------------------------
// AUDIO (Media3 + SoundPool)
// -------------------------------
@Singleton
class GameAudioManager @Inject constructor(
    @ApplicationContext private val context: Context,
    private val prefs: SequencePrefsRepository
) {
    private var musicEnabled: Boolean = true
    private var sfxEnabled: Boolean = true
    private var voiceEnabled: Boolean = true

    private val json = Json { ignoreUnknownKeys = true }

    private val soundPool: SoundPool = SoundPool.Builder()
        .setMaxStreams(8)
        .setAudioAttributes(
            AndroidAudioAttributes.Builder()
                .setUsage(AndroidAudioAttributes.USAGE_GAME)
                .setContentType(AndroidAudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
        )
        .build()

    private val soundIds = mutableMapOf<Int, Int>()
    private val loaded = mutableSetOf<Int>()

    private val musicPlayer: ExoPlayer = ExoPlayer.Builder(context).build().apply {
        setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(C.USAGE_GAME)
                .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                .build(),
            true
        )
        repeatMode = Player.REPEAT_MODE_ONE
        playWhenReady = false
    }

    private val voicePlayer: ExoPlayer = ExoPlayer.Builder(context).build().apply {
        setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(C.USAGE_GAME)
                .setContentType(C.AUDIO_CONTENT_TYPE_SPEECH)
                .build(),
            true
        )
        playWhenReady = false
    }

    init {
        // Observe settings
        // (We keep these coroutines in application scope by using DataStore flows + internal registration elsewhere.)
        // For simplicity here: the VM will call setEnabled flags when toggles change.
        preloadSfx(
            R.raw.buton_click,
            R.raw.sfx_bubble_pop,
            R.raw.sfx_correct_01, R.raw.sfx_correct_02, R.raw.sfx_correct_03, R.raw.sfx_correct_04, R.raw.sfx_correct_ding,
            R.raw.sfx_wrong_01, R.raw.sfx_wrong_02, R.raw.sfx_wrong_03, R.raw.sfx_wrong_04, R.raw.sfx_wrong_05, R.raw.sfx_wrong_06, R.raw.sfx_wrong_07, R.raw.sfx_wrong_08, R.raw.sfx_wrong_buzz,
            R.raw.sound_lion, R.raw.sound_elephant, R.raw.sound_cat, R.raw.sound_dog,
            R.raw.game_over
        )
    }

    private fun preloadSfx(@RawRes vararg resIds: Int) {
        soundPool.setOnLoadCompleteListener { _, sampleId, status ->
            if (status == 0) loaded.add(sampleId)
        }
        resIds.forEach { resId ->
            val id = soundPool.load(context, resId, 1)
            soundIds[resId] = id
        }
    }

    fun setMusicEnabled(v: Boolean) { musicEnabled = v; if (!v) pauseMusic() }
    fun setSfxEnabled(v: Boolean) { sfxEnabled = v }
    fun setVoiceEnabled(v: Boolean) { voiceEnabled = v }

    fun startGameplayMusic() {
        if (!musicEnabled) return
        val uri = RawResourceDataSource.buildRawResourceUri(R.raw.bg_music_loop)
        musicPlayer.setMediaItem(MediaItem.fromUri(uri))
        musicPlayer.prepare()
        musicPlayer.playWhenReady = true
    }

    fun pauseMusic() {
        musicPlayer.playWhenReady = false
        musicPlayer.pause()
    }

    fun resumeMusic() {
        if (!musicEnabled) return
        if (musicPlayer.mediaItemCount == 0) {
            startGameplayMusic()
        } else {
            musicPlayer.playWhenReady = true
            musicPlayer.play()
        }
    }

    fun stopMusic() {
        musicPlayer.stop()
        musicPlayer.clearMediaItems()
    }

    fun playTap() = playSfx(R.raw.buton_click, 0.9f)
    fun playSequenceTick() = playSfx(R.raw.sfx_bubble_pop, 1.0f)

    fun playCorrect() {
        val choices = listOf(R.raw.sfx_correct_01, R.raw.sfx_correct_02, R.raw.sfx_correct_03, R.raw.sfx_correct_04, R.raw.sfx_correct_ding)
        playSfx(choices.random(), 1.0f)
        playVoice(R.raw.voice_correct_bravo)
    }

    fun playWrong() {
        val choices = listOf(R.raw.sfx_wrong_01, R.raw.sfx_wrong_02, R.raw.sfx_wrong_03, R.raw.sfx_wrong_04, R.raw.sfx_wrong_05, R.raw.sfx_wrong_06, R.raw.sfx_wrong_07, R.raw.sfx_wrong_08, R.raw.sfx_wrong_buzz)
        playSfx(choices.random(), 1.0f)
        playVoice(R.raw.voice_wrong_oops)
    }

    fun playLevelComplete() {
        val choices = listOf(R.raw.sg_level_complete_01, R.raw.sg_level_complete_02)
        playSfx(choices.random(), 1.0f)
        playVoice(R.raw.voice_level_complete)
    }

    fun playGameOver() {
        playSfx(R.raw.game_over, 1.0f)
    }

    fun playAnimal(@RawRes animalRes: Int?) {
        if (animalRes == null) return
        playSfx(animalRes, 1.0f)
    }

    private fun playSfx(@RawRes resId: Int, volume: Float) {
        if (!sfxEnabled) return
        val sample = soundIds[resId] ?: return
        // SoundPool plays even if not fully loaded on some devices; safest is still try.
        soundPool.play(sample, volume, volume, 1, 0, 1.0f)
    }

    private fun playVoice(@RawRes resId: Int) {
        if (!voiceEnabled) return
        val uri = RawResourceDataSource.buildRawResourceUri(resId)
        voicePlayer.setMediaItem(MediaItem.fromUri(uri))
        voicePlayer.prepare()
        voicePlayer.playWhenReady = true
    }

    fun release() {
        soundPool.release()
        musicPlayer.release()
        voicePlayer.release()
    }

    fun encodeReplay(code: ReplayCode): String {
        val bytes = json.encodeToString(code).encodeToByteArray()
        return Base64.encodeToString(bytes, Base64.URL_SAFE or Base64.NO_WRAP)
    }

    fun decodeReplay(encoded: String): ReplayCode? = runCatching {
        val bytes = Base64.decode(encoded, Base64.URL_SAFE or Base64.NO_WRAP)
        json.decodeFromString<ReplayCode>(bytes.decodeToString())
    }.getOrNull()
}

// -------------------------------
// VIEWMODEL (game logic)
// -------------------------------
@HiltViewModel
class SequenceMemoryGameViewModel @Inject constructor(
    private val prefs: SequencePrefsRepository,
    private val audio: GameAudioManager
) : ViewModel() {

    private val _ui = MutableStateFlow(SequenceUiState())
    val ui: StateFlow<SequenceUiState> = _ui

    private var seed: Long = System.currentTimeMillis()
    private var rng = Random(seed)

    private var sequenceJob: Job? = null
    private var timerJob: Job? = null
    private var highScoreJob: Job? = null

    private val animalsIds = listOf(0, 1, 2, 3)

    init {
        // Last mode + corresponding high score
        viewModelScope.launch {
            prefs.lastMode.collectLatest { mode ->
                _ui.update { it.copy(mode = mode) }
                observeHighScore(mode)
            }
        }

        // Settings -> audio
        viewModelScope.launch { prefs.musicOn.collect { audio.setMusicEnabled(it) } }
        viewModelScope.launch { prefs.sfxOn.collect { audio.setSfxEnabled(it) } }
        viewModelScope.launch { prefs.voiceOn.collect { audio.setVoiceEnabled(it) } }
    }

    private fun observeHighScore(mode: GameMode) {
        highScoreJob?.cancel()
        highScoreJob = viewModelScope.launch {
            prefs.highScoreFlow(mode).collect { hs ->
                _ui.update { it.copy(highScore = hs) }
            }
        }
    }

    fun setMode(mode: GameMode) {
        viewModelScope.launch { prefs.setLastMode(mode) }
        // state will update via collector above
    }

    fun startNewGame(newSeed: Long? = null) {
        seed = newSeed ?: System.currentTimeMillis()
        rng = Random(seed)
        sequenceJob?.cancel()
        timerJob?.cancel()

        _ui.update {
            SequenceUiState(
                gameState = GameState.SHOWING_SEQUENCE,
                mode = it.mode,
                highScore = it.highScore // keep displayed HS
            )
        }

        addMoveAndShow()
    }

    fun resumeMusic() = audio.resumeMusic()
    fun pauseMusic() = audio.pauseMusic()

    fun toggleMusic(enabled: Boolean) = viewModelScope.launch { prefs.setMusicOn(enabled) }
    fun toggleSfx(enabled: Boolean) = viewModelScope.launch { prefs.setSfxOn(enabled) }
    fun toggleVoice(enabled: Boolean) = viewModelScope.launch { prefs.setVoiceOn(enabled) }

    fun useShield() {
        _ui.update { it.copy(shieldArmed = true) }
        audio.playTap()
    }

    fun useSlowMotion() {
        _ui.update { it.copy(slowMotionTurnsLeft = 2) } // affects next 2 turns/rounds
        audio.playTap()
    }

    fun useHint() {
        if (_ui.value.gameState != GameState.PLAYER_TURN) return
        audio.playTap()
        viewModelScope.launch {
            val expected = expectedNext()
            repeat(3) {
                _ui.update { it.copy(activeAnimalId = expected, robotEmotion = RobotEmotion.HINT) }
                audio.playSequenceTick()
                delay(220)
                _ui.update { it.copy(activeAnimalId = null, robotEmotion = RobotEmotion.IDLE) }
                delay(120)
            }
        }
    }

    fun onAnimalPressed(animalId: Int) {
        val state = _ui.value
        if (state.gameState != GameState.PLAYER_TURN) return

        timerJob?.cancel()

        val expected = expectedAtIndex(state.playerIndex)
        if (animalId == expected) {
            audio.playTap()
            audio.playAnimal(animalSoundResForId(animalId))

            val nextIndex = state.playerIndex + 1
            val roundComplete = nextIndex >= state.sequence.size

            if (roundComplete) {
                val newScore = state.score + 1

                _ui.update {
                    it.copy(
                        score = newScore,
                        playerIndex = 0,
                        gameState = GameState.IDLE,
                        robotEmotion = RobotEmotion.WIN,
                        showConfetti = true,
                        activeAnimalId = null,
                        starsAwardedThisRun = it.starsAwardedThisRun + 1,
                        slowMotionTurnsLeft = (it.slowMotionTurnsLeft - 1).coerceAtLeast(0)
                    )
                }

                // persist high score if needed
                if (newScore > state.highScore) {
                    viewModelScope.launch { prefs.setHighScore(state.mode, newScore) }
                }

                audio.playLevelComplete()

                // next round
                viewModelScope.launch {
                    delay(900)
                    _ui.update { it.copy(showConfetti = false, robotEmotion = RobotEmotion.IDLE) }
                    addMoveAndShow()
                }
            } else {
                _ui.update { it.copy(playerIndex = nextIndex, robotEmotion = RobotEmotion.HAPPY, activeAnimalId = animalId) }
                viewModelScope.launch {
                    delay(120)
                    _ui.update { it.copy(robotEmotion = RobotEmotion.IDLE, activeAnimalId = null) }
                    startTimerIfNeeded()
                }
                audio.playCorrect()
            }
        } else {
            // wrong
            if (state.shieldArmed) {
                _ui.update { it.copy(shieldArmed = false, robotEmotion = RobotEmotion.HINT) }
                audio.playWrong()
                viewModelScope.launch {
                    delay(500)
                    _ui.update { it.copy(robotEmotion = RobotEmotion.IDLE) }
                    startTimerIfNeeded()
                }
                return
            }

            _ui.update { it.copy(gameState = GameState.GAME_OVER, robotEmotion = RobotEmotion.SAD, activeAnimalId = animalId) }
            audio.playWrong()
            audio.playGameOver()
        }
    }

    fun makeShareCode(): String {
        val s = _ui.value
        return audio.encodeReplay(
            ReplayCode(mode = s.mode, seed = seed, sequence = s.sequence, score = s.score)
        )
    }

    fun loadShareCode(encoded: String): Boolean {
        val code = audio.decodeReplay(encoded) ?: return false
        seed = code.seed
        rng = Random(seed)

        sequenceJob?.cancel()
        timerJob?.cancel()

        _ui.value = SequenceUiState(
            gameState = GameState.SHOWING_SEQUENCE,
            mode = code.mode,
            score = code.score,
            sequence = code.sequence,
            playerIndex = 0
        )

        viewModelScope.launch { prefs.setLastMode(code.mode) }
        showSequenceOnly()
        return true
    }

    private fun expectedAtIndex(playerIndex: Int): Int {
        val s = _ui.value
        return when (s.mode) {
            GameMode.NORMAL, GameMode.TIMED -> s.sequence[playerIndex]
            GameMode.REVERSE -> s.sequence[s.sequence.lastIndex - playerIndex]
        }
    }

    private fun expectedNext(): Int = expectedAtIndex(_ui.value.playerIndex)

    private fun addMoveAndShow() {
        val nextMove = animalsIds[rng.nextInt(animalsIds.size)]
        _ui.update {
            it.copy(
                gameState = GameState.SHOWING_SEQUENCE,
                playerIndex = 0,
                robotEmotion = RobotEmotion.HINT,
                sequence = it.sequence + nextMove,
                activeAnimalId = null
            )
        }
        showSequenceOnly()
    }

    private fun showSequenceOnly() {
        sequenceJob?.cancel()
        timerJob?.cancel()

        sequenceJob = viewModelScope.launch {
            delay(550)

            val s = _ui.value
            val (onMs, gapMs) = showTimings(s.score, s.slowMotionTurnsLeft > 0)

            for (id in s.sequence) {
                if (!isActive) return@launch
                _ui.update { it.copy(activeAnimalId = id) }
                audio.playSequenceTick()
                audio.playAnimal(animalSoundResForId(id))
                delay(onMs)
                _ui.update { it.copy(activeAnimalId = null) }
                delay(gapMs)
            }

            _ui.update { it.copy(gameState = GameState.PLAYER_TURN, robotEmotion = RobotEmotion.IDLE) }
            startTimerIfNeeded()
        }
    }

    private fun showTimings(score: Int, slowMotion: Boolean): Pair<Long, Long> {
        val baseOn = (720 - score * 24).coerceAtLeast(360)
        val baseGap = (240 - score * 7).coerceAtLeast(110)
        val mul = if (slowMotion) 1.35 else 1.0
        return (baseOn * mul).toLong() to (baseGap * mul).toLong()
    }

    private fun startTimerIfNeeded() {
        if (_ui.value.mode != GameMode.TIMED || _ui.value.gameState != GameState.PLAYER_TURN) return
        timerJob?.cancel()

        val slow = _ui.value.slowMotionTurnsLeft > 0
        val total = timedBudgetMs(_ui.value.score, slow)
        _ui.update { it.copy(timeTotalMs = total, timeLeftMs = total) }

        timerJob = viewModelScope.launch {
            val start = System.currentTimeMillis()
            while (isActive) {
                val elapsed = System.currentTimeMillis() - start
                val left = (total - elapsed).coerceAtLeast(0)
                _ui.update { it.copy(timeLeftMs = left) }
                if (left <= 0) {
                    _ui.update { it.copy(gameState = GameState.GAME_OVER, robotEmotion = RobotEmotion.SAD) }
                    audio.playWrong()
                    audio.playGameOver()
                    return@launch
                }
                delay(50)
            }
        }
    }

    private fun timedBudgetMs(score: Int, slowMotion: Boolean): Long {
        val base = (2600 - score * 65).coerceAtLeast(1200)
        return (base + (if (slowMotion) 700 else 0)).toLong()
    }

    private fun animalSoundResForId(id: Int): Int? = when (id) {
        0 -> R.raw.sound_lion
        1 -> R.raw.sound_elephant
        2 -> R.raw.sound_cat // placeholder for Panda (we can generate real panda sound later)
        3 -> R.raw.sound_dog // placeholder for Vulpe (we can generate real fox sound later)
        else -> null
    }
}
// -------------------------------
// UI (Compose)
// -------------------------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SequenceMemoryGameScreen(
    navController: NavController,
    starState: MutableState<Int>,
    viewModel: SequenceMemoryGameViewModel = hiltViewModel()
) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val haptic = LocalHapticFeedback.current
    val ui by viewModel.ui.collectAsStateWithLifecycle()

    // Settings bottom sheet
    var showSettings by remember { mutableStateOf(false) }
    var shareToast by remember { mutableStateOf<String?>(null) }
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    // Pull prefs as UI toggles
    // (We read via DataStore flows directly for instant UI sync.)
    // Start/stop music with lifecycle
    LifecycleEventEffect(androidx.lifecycle.Lifecycle.Event.ON_RESUME) {
        viewModel.resumeMusic()
    }
    LifecycleEventEffect(androidx.lifecycle.Lifecycle.Event.ON_PAUSE) {
        viewModel.pauseMusic()
    }

    DisposableEffect(Unit) {
        // start music once when screen enters
        viewModel.resumeMusic()
        onDispose {
            viewModel.pauseMusic()
        }
    }

    val animals = remember {
        listOf(
            AnimalButtonData(0, Color(0xFFFFCDD2), R.drawable.leu, "Leu", R.raw.sound_lion),
            AnimalButtonData(1, Color(0xFFBBDEFB), R.drawable.elefant, "Elefant", R.raw.sound_elephant),
            AnimalButtonData(2, Color(0xFFC8E6C9), R.drawable.urs_panda, "Panda", R.raw.sound_cat),
            AnimalButtonData(3, Color(0xFFFFF9C4), R.drawable.vulpe_polara, "Vulpe", R.raw.sound_dog)
        )
    }

    // Award stars when VM says so (single source of truth in VM; currency stays outside)
    var lastAwarded by remember { mutableStateOf(0) }
    LaunchedEffect(ui.starsAwardedThisRun) {
        val delta = ui.starsAwardedThisRun - lastAwarded
        if (delta > 0) starState.value += delta
        lastAwarded = ui.starsAwardedThisRun
    }

    Box(modifier = Modifier.fillMaxSize()) {
        // Background (resource: drawable/bg_game_sequence.png)
        Image(
            painter = painterResource(R.drawable.bg_game_sequence),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.18f))
        )
        SparkleSpriteOverlay(
            modifier = Modifier.fillMaxSize(),
            sparkleRes = R.drawable.fx_star_sparkle
        )

        if (ui.showConfetti) {
            PremiumConfetti(modifier = Modifier.fillMaxSize().zIndex(10f))
        }

        // Top bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
                .align(Alignment.TopCenter),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { navController.popBackStack() }) {
                Image(
                    painter = painterResource(id = R.drawable.ui_btn_back_wood),
                    contentDescription = "Back",
                    modifier = Modifier.size(52.dp)
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                // Stars (currency)
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(999.dp))
                        .background(Color.White.copy(alpha = 0.85f))
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Image(painter = painterResource(R.drawable.ic_score_star), contentDescription = null, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(text = "${starState.value}", fontWeight = FontWeight.Black, color = Color(0xFF6A1B9A))
                }

                Spacer(Modifier.width(8.dp))

                IconButton(onClick = {
                    val code = viewModel.makeShareCode()
                    clipboard.setText(AnnotatedString(code))
                    shareToast = "Cod copiat!"
                }) {
                    Icon(Icons.Default.Share, contentDescription = "Share", tint = Color.White)
                }

                IconButton(onClick = { showSettings = true }) {
                    Icon(Icons.Default.Settings, contentDescription = "Settings", tint = Color.White)
                }
            }
        }

        // Main content
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
                .align(Alignment.Center),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Left: robot + score + mode
            Column(
                modifier = Modifier.weight(0.38f).fillMaxHeight(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                ScoreCard(score = ui.score, highScore = ui.highScore, mode = ui.mode)

                Spacer(Modifier.height(14.dp))

                ModeChips(
                    current = ui.mode,
                    enabled = ui.gameState == GameState.IDLE || ui.gameState == GameState.GAME_OVER,
                    onSelect = { viewModel.setMode(it) }
                )

                Spacer(Modifier.height(18.dp))

                MascotConductor(emotion = ui.robotEmotion, modifier = Modifier.height(210.dp))

                Spacer(Modifier.height(18.dp))

                if (ui.gameState == GameState.IDLE || ui.gameState == GameState.GAME_OVER) {
                    Button(
                        onClick = {
                            haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress)
                            viewModel.startNewGame()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF9800)),
                        modifier = Modifier.height(56.dp)
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null)
                        Spacer(Modifier.width(10.dp))
                        Text(
                            text = if (ui.gameState == GameState.GAME_OVER) "Din nou" else "Start",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                } else {
                    Text(
                        text = when (ui.gameState) {
                            GameState.SHOWING_SEQUENCE -> "Uită-te la secvență…"
                            GameState.PLAYER_TURN -> "Rândul tău!"
                            else -> ""
                        },
                        color = Color.White,
                        fontWeight = FontWeight.Black
                    )
                }

                Spacer(Modifier.height(16.dp))

                PowerUpsRow(
                    stars = starState.value,
                    shieldArmed = ui.shieldArmed,
                    slowMotionTurnsLeft = ui.slowMotionTurnsLeft,
                    enabled = ui.gameState == GameState.PLAYER_TURN,
                    onHint = { cost ->
                        if (starState.value >= cost) { starState.value -= cost; viewModel.useHint() }
                    },
                    onSlow = { cost ->
                        if (starState.value >= cost) { starState.value -= cost; viewModel.useSlowMotion() }
                    },
                    onShield = { cost ->
                        if (starState.value >= cost) { starState.value -= cost; viewModel.useShield() }
                    }
                )
            }

            // Right: board
            Box(
                modifier = Modifier
                    .weight(0.62f)
                    .fillMaxHeight(),
                contentAlignment = Alignment.Center
            ) {
                Surface(
                    shape = RoundedCornerShape(32.dp),
                    color = Color.White.copy(alpha = 0.22f),
                    shadowElevation = 10.dp,
                    modifier = Modifier.fillMaxSize(0.92f)
                ) {}

                Column(
                    verticalArrangement = Arrangement.SpaceEvenly,
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp)
                ) {
                    if (ui.mode == GameMode.TIMED && ui.gameState == GameState.PLAYER_TURN) {
                        val progress = if (ui.timeTotalMs <= 0L) 1f else (ui.timeLeftMs.toFloat() / ui.timeTotalMs.toFloat()).coerceIn(0f, 1f)
                        TurnTimerRing(progress = progress, modifier = Modifier.size(70.dp))
                    } else {
                        Spacer(Modifier.height(70.dp))
                    }

                    Row(horizontalArrangement = Arrangement.SpaceEvenly, modifier = Modifier.fillMaxWidth()) {
                        AnimalStar(
                            data = animals[0],
                            isActive = ui.activeAnimalId == 0,
                            canInteract = ui.gameState == GameState.PLAYER_TURN
                        ) {
                            haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.TextHandleMove)
                            viewModel.onAnimalPressed(0)
                        }
                        AnimalStar(
                            data = animals[1],
                            isActive = ui.activeAnimalId == 1,
                            canInteract = ui.gameState == GameState.PLAYER_TURN
                        ) {
                            haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.TextHandleMove)
                            viewModel.onAnimalPressed(1)
                        }
                    }
                    Row(horizontalArrangement = Arrangement.SpaceEvenly, modifier = Modifier.fillMaxWidth()) {
                        AnimalStar(
                            data = animals[2],
                            isActive = ui.activeAnimalId == 2,
                            canInteract = ui.gameState == GameState.PLAYER_TURN
                        ) {
                            haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.TextHandleMove)
                            viewModel.onAnimalPressed(2)
                        }
                        AnimalStar(
                            data = animals[3],
                            isActive = ui.activeAnimalId == 3,
                            canInteract = ui.gameState == GameState.PLAYER_TURN
                        ) {
                            haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.TextHandleMove)
                            viewModel.onAnimalPressed(3)
                        }
                    }
                }
            }
        }

        AnimatedVisibility(
            visible = shareToast != null,
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 18.dp)
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.Black.copy(alpha = 0.8f)),
                shape = RoundedCornerShape(999.dp)
            ) {
                Text(
                    text = shareToast ?: "",
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        LaunchedEffect(shareToast) {
            if (shareToast != null) {
                delay(1200)
                shareToast = null
            }
        }
    }

    if (showSettings) {
        ModalBottomSheet(
            onDismissRequest = { showSettings = false },
            sheetState = sheetState
        ) {
            SettingsSheet(
                onClose = { showSettings = false },
                onToggleMusic = { viewModel.toggleMusic(it) },
                onToggleSfx = { viewModel.toggleSfx(it) },
                onToggleVoice = { viewModel.toggleVoice(it) },
                onPasteShareCode = { code ->
                    val ok = viewModel.loadShareCode(code)
                    shareToast = if (ok) "Runda încărcată din cod!" else "Cod invalid 😅"
                }
            )
        }
    }
}

@Composable
private fun ScoreCard(score: Int, highScore: Int, mode: GameMode) {
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = Color.White.copy(alpha = 0.88f),
        shadowElevation = 8.dp,
        modifier = Modifier.fillMaxWidth().padding(horizontal = 6.dp)
    ) {
        Column(
            modifier = Modifier.padding(vertical = 14.dp, horizontal = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Scor", fontSize = 14.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
            Text("$score", fontSize = 34.sp, fontWeight = FontWeight.Black, color = Color(0xFF2E7D32))
            Spacer(Modifier.height(6.dp))
            Text("Maxim (${modeLabel(mode)}): $highScore", fontSize = 13.sp, color = Color(0xFF455A64), fontWeight = FontWeight.Bold)
        }
    }
}

private fun modeLabel(mode: GameMode) = when (mode) {
    GameMode.NORMAL -> "Normal"
    GameMode.REVERSE -> "Reverse"
    GameMode.TIMED -> "Timed"
}

@Composable
private fun ModeChips(current: GameMode, enabled: Boolean, onSelect: (GameMode) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(horizontal = 6.dp)) {
        GameMode.values().forEach { mode ->
            val selected = current == mode
            FilterChip(
                selected = selected,
                onClick = { if (enabled) onSelect(mode) },
                enabled = enabled,
                label = { Text(modeLabel(mode), fontWeight = FontWeight.Black) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = Color.White.copy(alpha = 0.9f),
                    containerColor = Color.White.copy(alpha = 0.35f),
                    labelColor = if (selected) Color(0xFF1B5E20) else Color.White,
                    selectedLabelColor = Color(0xFF1B5E20)
                )
            )
        }
    }
}

@Composable
private fun PowerUpsRow(
    stars: Int,
    shieldArmed: Boolean,
    slowMotionTurnsLeft: Int,
    enabled: Boolean,
    onHint: (cost: Int) -> Unit,
    onSlow: (cost: Int) -> Unit,
    onShield: (cost: Int) -> Unit
) {
    val hintCost = 2
    val slowCost = 3
    val shieldCost = 5

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Power-ups", color = Color.White, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            PowerUpButton(
                icon = Icons.Default.TipsAndUpdates,
                title = "Hint",
                cost = hintCost,
                stars = stars,
                enabled = enabled,
                active = false
            ) { onHint(hintCost) }
            PowerUpButton(
                icon = Icons.Default.SlowMotionVideo,
                title = "Slow",
                cost = slowCost,
                stars = stars,
                enabled = enabled,
                active = slowMotionTurnsLeft > 0
            ) { onSlow(slowCost) }
            PowerUpButton(
                icon = Icons.Default.Shield,
                title = "Shield",
                cost = shieldCost,
                stars = stars,
                enabled = enabled,
                active = shieldArmed
            ) { onShield(shieldCost) }
        }
    }
}

@Composable
private fun PowerUpButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    cost: Int,
    stars: Int,
    enabled: Boolean,
    active: Boolean,
    onClick: () -> Unit
) {
    val canAfford = stars >= cost
    val alpha = if (enabled && canAfford) 1f else 0.55f
    val borderColor = if (active) Color(0xFFFFD54F) else Color.White.copy(alpha = 0.6f)

    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.alpha(alpha)) {
        Surface(
            onClick = { if (enabled && canAfford) onClick() },
            enabled = enabled && canAfford,
            shape = RoundedCornerShape(16.dp),
            color = Color.White.copy(alpha = 0.22f),
            border = androidx.compose.foundation.BorderStroke(2.dp, borderColor),
            shadowElevation = 6.dp
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)
            ) {
                Icon(icon, contentDescription = null, tint = Color.White)
                Spacer(Modifier.width(6.dp))
                Text(title, color = Color.White, fontWeight = FontWeight.Black)
            }
        }
        Spacer(Modifier.height(4.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Image(painter = painterResource(R.drawable.ic_score_star), contentDescription = null, modifier = Modifier.size(14.dp))
            Spacer(Modifier.width(4.dp))
            Text("$cost", color = Color.White, fontWeight = FontWeight.Black, fontSize = 12.sp)
        }
    }
}

@Composable
fun AnimalStar(
    data: AnimalButtonData,
    isActive: Boolean,
    canInteract: Boolean,
    onClick: () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    val scale by animateFloatAsState(
        targetValue = if (isActive || isPressed) 1.18f else 1f,
        animationSpec = spring(dampingRatio = 0.42f, stiffness = 420f),
        label = "scale"
    )
    val glowAlpha by animateFloatAsState(
        targetValue = if (isActive) 0.9f else 0.0f,
        animationSpec = tween(160),
        label = "glow"
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .scale(scale)
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                enabled = canInteract,
                onClick = onClick
            )
    ) {
        Box(contentAlignment = Alignment.Center) {
            // Glow
            Box(
                modifier = Modifier
                    .size(128.dp)
                    .clip(CircleShape)
                    .background(Brush.radialGradient(listOf(data.color, Color.Transparent)))
                    .graphicsLayer { alpha = glowAlpha }
            )
            // Button
            Surface(
                shape = CircleShape,
                color = Color.White,
                border = androidx.compose.foundation.BorderStroke(3.dp, data.color),
                shadowElevation = 10.dp,
                modifier = Modifier.size(106.dp)
            ) {
                Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(12.dp)) {
                    Image(
                        painter = painterResource(id = data.imageRes),
                        contentDescription = data.name,
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }
        }
    }
}

@Composable
fun MascotConductor(emotion: RobotEmotion, modifier: Modifier = Modifier) {
    val resId = when (emotion) {
        RobotEmotion.HAPPY -> R.drawable.robot_happy
        RobotEmotion.SAD -> R.drawable.robot_sad
        RobotEmotion.HINT -> R.drawable.robot_hint
        RobotEmotion.WIN -> R.drawable.robot_win
        else -> R.drawable.robot_idle
    }
    val infinite = rememberInfiniteTransition(label = "robot")
    val baseRotation by infinite.animateFloat(
        initialValue = -3.5f,
        targetValue = 3.5f,
        animationSpec = infiniteRepeatable(tween(1200), RepeatMode.Reverse),
        label = "rot"
    )
    val wobble = when (emotion) {
        RobotEmotion.HINT -> baseRotation * 3
        RobotEmotion.SAD -> baseRotation * 1.2f
        RobotEmotion.WIN -> baseRotation * 2.2f
        else -> baseRotation
    }

    Image(
        painter = painterResource(id = resId),
        contentDescription = "Robot",
        modifier = modifier
            .graphicsLayer { rotationZ = wobble }
            .shadow(10.dp, CircleShape)
    )
}

@Composable
fun TurnTimerRing(progress: Float, modifier: Modifier = Modifier) {
    androidx.compose.foundation.Canvas(modifier = modifier) {
        val stroke = 10.dp.toPx()
        val pad = stroke / 2
        val size = Size(this.size.width - pad * 2, this.size.height - pad * 2)
        val topLeft = Offset(pad, pad)

        // background ring
        drawArc(
            color = Color.White.copy(alpha = 0.22f),
            startAngle = -90f,
            sweepAngle = 360f,
            useCenter = false,
            topLeft = topLeft,
            size = size,
            style = Stroke(width = stroke, cap = StrokeCap.Round)
        )
        // progress ring
        drawArc(
            color = Color.White,
            startAngle = -90f,
            sweepAngle = 360f * progress,
            useCenter = false,
            topLeft = topLeft,
            size = size,
            style = Stroke(width = stroke, cap = StrokeCap.Round)
        )
    }
}

@Composable
fun SparkleSpriteOverlay(modifier: Modifier = Modifier, sparkleRes: Int) {
    BoxWithConstraints(modifier = modifier) {

        val sparkles = remember {
            List(18) {
                SequenceSparkle(
                    x = Random.nextFloat(),
                    y = Random.nextFloat(),
                    size = 18 + Random.nextInt(22),
                    phase = Random.nextFloat() * (2f * PI).toFloat(),
                    drift = (0.012f + Random.nextFloat() * 0.02f),
                    rot = Random.nextFloat() * 360f
                )
            }
        }

        val t = rememberInfiniteTransition(label = "sparkleTrans")
        val p by t.animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(2400), RepeatMode.Restart),
            label = "p"
        )

        sparkles.forEach { s ->
            val alpha = 0.25f + 0.55f * ((sin(s.phase + p * 2f * PI.toFloat()) + 1f) / 2f)
            val yDrift = (s.y + p * s.drift) % 1f

            Image(
                painter = painterResource(sparkleRes),
                contentDescription = null,
                modifier = Modifier
                    .offset(maxWidth * s.x, maxHeight * yDrift)
                    .size(s.size.dp)
                    .alpha(alpha)
                    .rotate(s.rot + p * 60f)
            )
        }
    }
}

private data class SequenceSparkle(
    val x: Float,
    val y: Float,
    val size: Int,
    val phase: Float,
    val drift: Float,
    val rot: Float
)

@Composable
private fun SettingsSheet(
    onClose: () -> Unit,
    onToggleMusic: (Boolean) -> Unit,
    onToggleSfx: (Boolean) -> Unit,
    onToggleVoice: (Boolean) -> Unit,
    onPasteShareCode: (String) -> Unit
) {
    val context = LocalContext.current
    val ds = context.gamePrefs

    val musicOn by ds.data.map { it[booleanPreferencesKey("music_on")] ?: true }.collectAsStateWithLifecycle(initialValue = true)
    val sfxOn by ds.data.map { it[booleanPreferencesKey("sfx_on")] ?: true }.collectAsStateWithLifecycle(initialValue = true)
    val voiceOn by ds.data.map { it[booleanPreferencesKey("voice_on")] ?: true }.collectAsStateWithLifecycle(initialValue = true)

    var shareCode by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
        Text("Setări", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(10.dp))
        Divider()

        Spacer(Modifier.height(10.dp))
        SettingsToggleRow("Muzică", musicOn) { onToggleMusic(it) }
        SettingsToggleRow("Efecte (SFX)", sfxOn) { onToggleSfx(it) }
        SettingsToggleRow("Voce", voiceOn) { onToggleVoice(it) }

        Spacer(Modifier.height(12.dp))
        Divider()
        Spacer(Modifier.height(12.dp))

        Text("Încarcă rundă din cod", fontWeight = FontWeight.Black)
        Spacer(Modifier.height(6.dp))

        androidx.compose.material3.OutlinedTextField(
            value = shareCode,
            onValueChange = { shareCode = it },
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Lipește codul aici…") },
            singleLine = true
        )
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(
                onClick = { onPasteShareCode(shareCode.trim()) },
                enabled = shareCode.isNotBlank()
            ) { Text("Încarcă") }
            Button(onClick = onClose, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF607D8B))) {
                Text("Închide")
            }
        }

        Spacer(Modifier.height(10.dp))
    }
}

@Composable
private fun SettingsToggleRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, fontWeight = FontWeight.Bold)
        Checkbox(checked = checked, onCheckedChange = onChange)
    }
}
