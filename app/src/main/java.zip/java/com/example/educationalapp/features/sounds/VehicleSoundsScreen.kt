package com.example.educationalapp.features.sounds

import android.net.Uri
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.Card
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.educationalapp.ui.components.SpriteAnimation
import com.example.educationalapp.ui.components.rememberAssetSheet
import com.example.educationalapp.ui.media.rememberSoundPlayer
import com.example.educationalapp.utils.toSafeFileName

data class VehicleSprite(val name: String, val assetPath: String, val frameCount: Int, val columns: Int, val fps: Int)

// TODO: Replace with actual vehicle data and assets
val vehicleSprites = listOf(
    VehicleSprite("Car", "sprites/car.webp", 60, 8, 24),
    VehicleSprite("Train", "sprites/train.webp", 60, 8, 24),
    VehicleSprite("Plane", "sprites/plane.webp", 60, 8, 24),
    VehicleSprite("Boat", "sprites/boat.webp", 60, 8, 24),
)

@Composable
fun VehicleSoundsScreen() {
    LazyVerticalGrid(
        columns = GridCells.Adaptive(minSize = 128.dp),
        contentPadding = PaddingValues(16.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        items(vehicleSprites) { vehicle ->
            var isPlaying by remember { mutableStateOf(false) }
            val sheet = rememberAssetSheet(path = vehicle.assetPath)

            val soundFileName = vehicle.name.toSafeFileName()
            val soundUri = remember(soundFileName) {
                Uri.parse("asset:///sounds/vehicles/$soundFileName.mp3")
            }

            val soundPlayer = rememberSoundPlayer(soundUri = soundUri) {
                isPlaying = false
            }

            Card(
                modifier = Modifier.clickable {
                    if (!isPlaying) {
                        soundPlayer.seekTo(0)
                        soundPlayer.play()
                        isPlaying = true
                    } else {
                        soundPlayer.seekTo(0)
                        soundPlayer.play()
                    }
                }
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(1f)
                        .padding(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Top
                ) {
                    if (sheet != null) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f),
                            contentAlignment = Alignment.Center
                        ) {
                            SpriteAnimation(
                                sheet = sheet,
                                frameCount = vehicle.frameCount,
                                columns = vehicle.columns,
                                fps = vehicle.fps,
                                isPlaying = isPlaying,
                                modifier = Modifier.fillMaxSize(0.9f)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = vehicle.name)
                }
            }
        }
    }
}
