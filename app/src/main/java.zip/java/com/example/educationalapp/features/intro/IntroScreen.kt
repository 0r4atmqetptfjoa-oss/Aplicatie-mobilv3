package com.example.educationalapp.features.intro

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.educationalapp.ParallaxMainMenuBackground
import com.example.educationalapp.R
import com.example.educationalapp.fx.AmbientMagicParticles
import com.example.educationalapp.fx.rememberDrawableId
import kotlinx.coroutines.delay

@Composable
fun IntroScreen(
    onDone: () -> Unit
) {
    var startAnim by remember { mutableStateOf(false) }

    val alpha by animateFloatAsState(
        targetValue = if (startAnim) 1f else 0f,
        animationSpec = tween(700, easing = FastOutSlowInEasing),
        label = "introAlpha"
    )
    val scale by animateFloatAsState(
        targetValue = if (startAnim) 1f else 0.86f,
        animationSpec = tween(700, easing = FastOutSlowInEasing),
        label = "introScale"
    )

    LaunchedEffect(Unit) {
        startAnim = true
        delay(1700)
        onDone()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .clickable { onDone() }
    ) {
        ParallaxMainMenuBackground()

        // optional cinematic overlays (safe even if missing)
        OptionalOverlay(name = "overlay_vignette", alpha = 0.55f)
        OptionalOverlay(name = "overlay_bokeh", alpha = 0.32f)
        OptionalOverlay(name = "overlay_light_rays", alpha = 0.28f)

        AmbientMagicParticles()

        // Title with glow
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Image(
                painter = painterResource(R.drawable.main_menu_title),
                contentDescription = null,
                modifier = Modifier
                    .fillMaxWidth(0.62f)
                    .graphicsLayer {
                        this.alpha = alpha * 0.65f
                        scaleX = scale * 1.03f
                        scaleY = scale * 1.03f
                    }
                    .blur(18.dp),
                contentScale = ContentScale.Fit
            )

            Image(
                painter = painterResource(R.drawable.main_menu_title),
                contentDescription = null,
                modifier = Modifier
                    .fillMaxWidth(0.62f)
                    .graphicsLayer {
                        this.alpha = alpha
                        scaleX = scale
                        scaleY = scale
                    },
                contentScale = ContentScale.Fit
            )
        }

        Text(
            text = "Atinge ca să începi",
            style = MaterialTheme.typography.titleMedium.copy(
                color = Color.White,
                fontSize = 18.sp,
                shadow = Shadow(Color(0xAA000000), Offset(1f, 2f), 6f)
            ),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 28.dp)
        )
    }
}

@Composable
private fun OptionalOverlay(name: String, alpha: Float) {
    val id = rememberDrawableId(name, fallback = 0)
    if (id != 0) {
        Image(
            painter = painterResource(id),
            contentDescription = null,
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer { this.alpha = alpha },
            contentScale = ContentScale.Crop
        )
    }
}
