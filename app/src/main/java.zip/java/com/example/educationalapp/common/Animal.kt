package com.example.educationalapp

data class Animal(val name: String, val emoji: String, val category: String? = null)
