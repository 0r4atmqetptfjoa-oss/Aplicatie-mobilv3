package com.example.educationalapp

// Fișier marcat pentru ștergere/neutilizare.
// Funcționalitatea a fost mutată în ParallaxMainMenuBackground.kt
