// This file was removed because it caused a Hilt multiple app roots error.
// The main application class is now com.example.educationalapp.core.EducationalApp.
