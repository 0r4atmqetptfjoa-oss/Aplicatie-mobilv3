package com.example.educationalapp

data class MemoryCard(val id: Int, val value: String, var isFaceUp: Boolean = false, var isMatched: Boolean = false)
